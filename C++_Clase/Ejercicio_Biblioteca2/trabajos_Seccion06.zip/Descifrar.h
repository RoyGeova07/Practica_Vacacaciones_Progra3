//Roy Umaña 22411312}
#include <iostream>

#include <stdlib.h>


class Descifrar
{
private:
    


public:
    
    int Cifrar(int numero);
    int Desifrar(int numero);

};


