#include <iostream>
using std::cout;
 using std::endl;

int main(){

    int c;
    c=5;
    cout<<c<<endl;
    cout<<c++<<endl;
    cout<<c<<endl;

    cout<<endl;

    c=5;
    cout<<c<<endl;
    cout<<++c<<endl;
    cout<<c<<endl;

    return 0;
}