class Analisis
{
private:
   


public:
    
    void ProcesarResultadoExamen();

};

